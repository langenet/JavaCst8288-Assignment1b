/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elevatorsystem;

import elevator.ElevatorModel;
import elevator.MovingState;
import java.util.Observable;
import java.util.Observer;
import elevator.IElevator;

/**
 *
 * @author Robert (Controller)
 */
public class ElevatorController implements IElevatorController, IElevatorPanel {
    
    private int MAX_FLOOR;
    private int MIN_FLOOR;
    private IElevator elevator;
    
    public ElevatorController(int MAX_FLOOR, int MIN_FLOOR) {
        this.MAX_FLOOR = MAX_FLOOR;
        this.MIN_FLOOR = MIN_FLOOR;
    }
   


    private void floorCheck(int floor){
       
    }
    
    private IElevator call(int floor, MovingState direction){

        return null;
    }
    
    private boolean checkForElevator(){
       
        if (elevator != null) {
            return true;
        }else{
             return false;
        }
    }
    
    public ElevatorModel getElevator(){
        return (ElevatorModel)elevator;
    }
    
    @Override
    public int getFloorCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getMaxFloor() {
        return MAX_FLOOR;
    }

    @Override
    public int getMinFloor() {
        return MIN_FLOOR;
    }

    @Override
    public IElevator callUp(int floor) {
        System.out.println("Getting elevator to floor: " + floor + " to go up.");
        elevator.moveTo(floor);
        return elevator;
    }

    @Override
    public IElevator callDown(int floor) {
        System.out.println("Getting elevator to floor: " + floor + " to go down.");
        elevator.moveTo(floor);     
        return elevator;
    }

    @Override
    public int getCurrentFloor() {
        return elevator.getFloor();
    }

    @Override
    public double getPowerConsumed() {
        return elevator.getPowerConsumed();
    }

    @Override
    public void addElevator(IElevator elevator) {
        this.elevator = elevator;
    }

     @Override
    public void requestStop(int floor, IElevator elevator) {
        System.out.println("The elevator is leaving floor " + getCurrentFloor() + " to go to floor " + floor );
        elevator.moveTo(floor);
        
    }
    
}
