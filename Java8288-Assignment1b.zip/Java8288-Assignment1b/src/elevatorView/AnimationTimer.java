/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elevatorView;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 *
 * @author Robert
 */

public class AnimationTimer {
    
    private Queue<List<Integer>> queue = new LinkedList<>();
    private int currentFloor ;
    private int targetFloor;
    private double energy;

    public AnimationTimer(){
        
    }
  

    public void add(int currentFloor, int targetFloor, double energy){
        this.setCurrentFloor(currentFloor);
        this.setTargetFloor(targetFloor);
        this.setEnergy(energy);
        
        System.err.println("powerConsumed Test " + getEnergy());
        System.err.println("CurrentFloor Test " + getCurrentFloor() );
        System.err.println("TargetFloor Test " + getTargetFloor() );
      
     //   queue.add(getEnergy());
        
    }
    
    public int poll(){
        return -1;
    }
    
    
    public void setQueue(Queue<List<Integer>> queue) {
        this.queue = queue;
    }
   
    public Queue<List<Integer>> getQueue() {
        return queue;
    }

    public int getCurrentFloor() {
        return currentFloor;
    }

    public void setCurrentFloor(int currentFloor) {
        this.currentFloor = currentFloor;
    }

    public int getTargetFloor() {
        return targetFloor;
    }

    public void setTargetFloor(int targetFloor) {
        this.targetFloor = targetFloor;
    }

   public double getEnergy() {
        return energy;
    }

    public void setEnergy(double energy) {
        this.energy = energy;
    }
 
    
    
   
    
}
