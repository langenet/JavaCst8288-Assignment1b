/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elevatorView;

import elevator.MovingState;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import javax.swing.Timer;

/**
 *
 * @author Robert
 */

public class AnimationTimer {
    
    private Queue<List<Double>> queue = new LinkedList<>();
    private double currentFloor;
    private double targetFloor;
    private double energy;
    private double currentElevatorState;

    static StringBuffer sb = new StringBuffer();
    
    public double getCurrentElevatorState() {
        return currentElevatorState;
    }

    public void setCurrentElevatorState(double currentElevatorState) {
        this.currentElevatorState = currentElevatorState;
    }

    private Timer timer;
    
    
    public AnimationTimer(){
        
        timer = new Timer(1000, new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt){
                if(getQueue().isEmpty()){
                    timer.stop();
                    ElevatorApplication.getActivityTextField().setText(MovingState.Idle.toString());
                    return;
                }
                List<Double> updatedValues = getQueue().poll();
                ElevatorApplication.getCurrentFloorTextField().setText(updatedValues.get(0).toString());
                ElevatorApplication.getTargetFloorTextField().setText(updatedValues.get(1).toString());
                ElevatorApplication.getPowerConsumedTextField().setText(updatedValues.get(2).toString());
                
                int enumInt = updatedValues.get(3).intValue();
                for(MovingState state:MovingState.values()){
                    if(enumInt == state.ordinal() ){  
                        if(enumInt == 2 || enumInt == 0){
                            sb.append("#");
                            ElevatorApplication.getActivityTextField().setText(sb.toString());
                        }else if(enumInt == 3 || enumInt == 1){ 
                            sb.deleteCharAt(sb.length() - 1);
                            ElevatorApplication.getActivityTextField().setText(sb.toString());
                        }
                        
    //                   ElevatorApplication.getActivityTextField().setText(state.toString());                  
                    }
                }
            }
            
            
        });
        
        timer.start();
        
    }

    public void add(double currentFloor, double targetFloor, double energy, double currentElevatorState){
        this.setCurrentFloor(currentFloor);
        this.setTargetFloor(targetFloor);
        this.setEnergy(energy);
        this.setCurrentElevatorState(currentElevatorState);
        
         List<Double> updatedValues = new ArrayList<>();
            updatedValues.add(getCurrentFloor());
            updatedValues.add(getTargetFloor());
            updatedValues.add(getEnergy());
            updatedValues.add(getCurrentElevatorState());
            this.getQueue().add(updatedValues);
    }
    
    public int poll(){
        return -1;
    }
    
    
    public void setQueue(Queue<List<Double>> queue) {
        this.queue = queue;
    }
   
    public Queue<List<Double>> getQueue() {
        return queue;
    }

    public double getCurrentFloor() {
        return currentFloor;
    }

    public void setCurrentFloor(double currentFloor) {
        this.currentFloor = currentFloor;
    }

    public double getTargetFloor() {
        return targetFloor;
    }

    public void setTargetFloor(double targetFloor) {
        this.targetFloor = targetFloor;
    }

   public double getEnergy() {
        return energy;
    }

    public void setEnergy(double energy) {
        this.energy = energy;
    }
 
    
    
   
    
}
