package elevatorView;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import elevator.ElevatorModel;
import elevator.MovingState;
import java.awt.GridLayout;
import java.util.Observable;
import java.util.Observer;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author Robert
 */
public class ElevatorApplication extends JFrame implements Observer{
    
   private ElevatorModel elevator;
    
    private JTextField currentFloorTextField;
    private JTextField targetFloorTextField;
    private JTextField powerConsumedTextField;
    private JTextField activityTextField;
    
    
    public ElevatorApplication() {
    JFrame frame = new JFrame("Elevator System Inc.");   
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(500,500);
                
    GridLayout grid = new GridLayout(8,1);
    frame.setLayout(grid);
        
    
    JLabel currentFloor = new JLabel("Current Floor");
    JLabel targetFloor = new JLabel("Target Floor");
    JLabel powerConsumed = new JLabel("Power Consumed");
    JLabel activity = new JLabel("Activity");
    
    currentFloorTextField =  new JTextField(10);
    currentFloorTextField.setEditable(false);
    
    targetFloorTextField =  new JTextField(10);
    targetFloorTextField.setEditable(false);
    
    powerConsumedTextField =  new JTextField(10);
    powerConsumedTextField.setEditable(false);
    
    activityTextField = new JTextField(10);
    activityTextField.setEditable(false);
    
    frame.add(currentFloor);
    frame.add(currentFloorTextField);
    
    frame.add(targetFloor);
    frame.add(targetFloorTextField);
    
    frame.add(powerConsumed);
    frame.add(powerConsumedTextField);
    
    frame.add(activity);
    frame.add(activityTextField);
    
    frame.setVisible(true);        
    } 
    
    static StringBuilder sb = new StringBuilder();

    @Override
    public void update(Observable observed, Object arg) {
       int currentfloor;
       int targetFloor;
       double energy;
       
       
        if(observed instanceof ElevatorModel){
            
          System.err.println("Moved to : " + ((ElevatorModel)observed).getFloor());
               
          currentfloor = (int)((ElevatorModel)observed).getFloor();
          energy = (double) ((ElevatorModel)observed).getPowerConsumed();
          targetFloor = (int) ((ElevatorModel)observed).getTargetFloor();
          
          AnimationTimer atq = new AnimationTimer();
          atq.add(currentfloor, targetFloor, energy);
        
               
//               if(((ElevatorModel)observed).getState() != MovingState.Off && ((ElevatorModel)observed).getState() != MovingState.Up) {
//                   System.err.println("going up");
//                   sb.append("#");
//                   activityTextField.setText(sb.toString());
//             }
              
               
        }
        
       
        
        
     
        
    }      
    
}
