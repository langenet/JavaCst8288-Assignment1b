/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elevator;

import java.util.Observable;
import elevatorsystem.IElevatorPanel;

/**
 *
 * @author Robert (Model)
 */
public class ElevatorModel extends Observable implements IElevator {

    private int POWER_START_STOP = 2;
    private int POWER_CONTINUOUS = 1;

    private long SLEEP_START_STOP = 50;
    private long SLEEP_CONTINUOUS = 25;
    private double MAX_CAPACITY_PERSONS;

    private IElevatorPanel panel;
    private MovingState state;
    private double powerUsed;

    private int currentFloor;
    private int targetFloor;

    public int getTargetFloor() {
        return targetFloor;
    }

    public void setTargetFloor(int targetFloor) {
        this.targetFloor = targetFloor;
    }

    public void setCurrentFloor(int currentFloor) {
        this.currentFloor = currentFloor;
    }

    private int capacity;

    public ElevatorModel(double MAX_CAPACITY_PERSONS, IElevatorPanel panel) {
        this.MAX_CAPACITY_PERSONS = MAX_CAPACITY_PERSONS;
        this.panel = panel;
        this.powerUsed = 0.0;
        this.currentFloor = 0;  //starting point
        this.capacity = 0;
        this.state = MovingState.Idle;
        
    }

    @Override
    public void moveTo(int targetFloor) {
      
        this.setTargetFloor(targetFloor);       
    
        
        if (targetFloor < 0) {
            System.out.println(targetFloor + " does not exists.");
        }

        if (getFloor() == targetFloor) {
            System.out.println("You have arrived at floor " + targetFloor);
        }
          /* states of movement
        1. state = idle
        2. state = slow (start moving)
        3. state = normal (loop through moving normally until you are 1 floor away from destination
        4. state = slow for the last step.
         */

        while (getFloor() != targetFloor) { //not already on that floor
            System.out.print("Elevator state old state = " + getState() + ". ");
            double tempPower;

            if (getState() == MovingState.Idle || Math.abs(targetFloor - getFloor()) <= 1.0) { //verify this is the best abs
             //   setState(getFloor() < targetFloor ? MovingState.SlowUp : MovingState.SlowDown);
                if(getFloor() < targetFloor){
                    setState(MovingState.SlowUp);
                }else{
                    setState(MovingState.SlowDown);
                }          
                setPowerConsumed(2.0);
                tempPower = 2.0;
            } else {
                setState(getState().normal());
                setPowerConsumed(1.0);
                tempPower = 1.0;

            }

            System.out.println(" New state = " + getState() + ". "+ " Power consumted is = " + tempPower);

        
            
            if(getFloor() < targetFloor){
                setFloor(getFloor() + 1);
            }else{
                setFloor(getFloor() - 1);
            }

            setChanged();
            notifyObservers(this);
            
            System.out.println("Moved to floor " + getFloor());;

        }

        System.out.print("The Elevator changed from state " + getState());

        setState(MovingState.Idle);

        System.out.println(" to state " + getState());

    }

     @Override
    public int getFloor() {
        return currentFloor;
    }
    
    private void setFloor(int floor){
        this.currentFloor = floor;
    }
    
    public void setPowerUsed(double powerUsed) {

        /*  Elevator consumes energy
        a. One kilowatt (kW) is consumed for each full floor travel (example below).
        b. Two kilowatt (kW) is consumed for each start and stop.
         */
        this.powerUsed += powerUsed;
    }

    private void processMovingState(int floor) {
        //notify here???
        setChanged();
        notifyObservers();
    }

    @Override
    public int getCapacity() {
        return capacity;
    }

    @Override
    public boolean isFull() {
        return getCapacity() > MAX_CAPACITY_PERSONS;
    }

    @Override
    public boolean isEmpty() {
        return getCapacity() == 0;
    }

    @Override
    public MovingState getState() {
        return state;

    }
    
    public void setState(MovingState state){
        this.state = state;
    }
    @Override
    public double getPowerConsumed() {
      
        return powerUsed;
    }

     public void setPowerConsumed(double power){
        this.powerUsed += power;
    }
     
    @Override
    public void addPersons(int persons) {
        this.capacity =+ persons;
        System.out.println("picked up " + persons + " passenger(s) at floor " + getFloor() );
    }

    @Override
    public void requestStop(int floor) {
        System.out.println("The elevator is leaving floor " + getFloor() + " to go to floor " + floor );
        moveTo(floor);
    }

}
