package elevatorView;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import elevator.ElevatorModel;
import java.awt.GridLayout;
import java.util.Observable;
import java.util.Observer;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author Robert
 */
public class ElevatorApplication extends JFrame implements Observer{
    
   private ElevatorModel elevator;
    
    private JTextField currentFloorTextField;
    private JTextField targetFloorTextField;
    private JTextField powerConsumedTextField;
    private JTextField activityTextField;
    
    
    public ElevatorApplication() {
    JFrame frame = new JFrame("Elevator System Inc.");   
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(500,500);
                
    GridLayout grid = new GridLayout(8,1);
    frame.setLayout(grid);
        
    
    JLabel currentFloor = new JLabel("Current Floor");
    JLabel targetFloor = new JLabel("Target Floor");
    JLabel powerConsumed = new JLabel("Power Consumed");
    JLabel activity = new JLabel("Activity");
    
    currentFloorTextField =  new JTextField(10);
    currentFloorTextField.setEditable(false);
    
    targetFloorTextField =  new JTextField(10);
    targetFloorTextField.setEditable(false);
    
    powerConsumedTextField =  new JTextField(10);
    powerConsumedTextField.setEditable(false);
    
    activityTextField = new JTextField(10);
    activityTextField.setEditable(false);
    
    frame.add(currentFloor);
    frame.add(currentFloorTextField);
    
    frame.add(targetFloor);
    frame.add(targetFloorTextField);
    
    frame.add(powerConsumed);
    frame.add(activity);
    
    frame.setVisible(true);
    
    
            
    
    } 

    @Override
    public void update(Observable observed, Object arg) {
       int floor;
       int newFloor;
       
        if(observed instanceof ElevatorModel){
               System.err.println("Moved to : " + ((ElevatorModel)observed).getFloor());
        }
        
        StringBuffer sb = new StringBuffer();
        
        
     
        
    }      
    
}
