/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elevator;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Robert
 */
public class ElevatorApplication extends JPanel{
    private JLabel label;
    public ElevatorApplication(){
        
    }
    
    JFrame frame = new JFrame("Elevator");
    
    
    
    
}
