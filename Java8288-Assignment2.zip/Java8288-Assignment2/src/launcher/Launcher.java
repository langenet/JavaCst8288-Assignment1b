/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package launcher;

/**
 *
 * @author Robert
 */
import elevator.ElevatorModel;
import elevatorsystem.ElevatorController;
import elevator.IElevator;
import elevatorsystem.IElevatorController;
import elevatorsystem.IElevatorPanel;

public class Launcher{

	public static void main( String[] args){
		final int MIN_FLOOR = 0;
		final int MAX_FLOOR = 20;
		IElevatorController system = new ElevatorController( MIN_FLOOR, MAX_FLOOR);           
		system.addElevator(new ElevatorModel( 5, (IElevatorPanel)system));
		IElevator elevator = system.callDown( 3);
		elevator.addPersons( 1);
		elevator.requestStop( 0);
	}
}
